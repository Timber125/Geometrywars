/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geometrywars.Rendering;

import geometrywars.Game.Objects.Player;
import geometrywars.Rendering.Engine.RenderLevel;

/**
 *
 * @author timber
 */
public class ObjectFactory {
    public static ObjectFactory instance = new ObjectFactory();
    private static final Long Player1_ID = 1L;
    
    public ObjectFactory(){
        
    }
    
    
    
}
