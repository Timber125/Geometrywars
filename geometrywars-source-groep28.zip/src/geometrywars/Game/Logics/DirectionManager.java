/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geometrywars.Game.Logics;

import geometrywars.Rendering.Renderable;

/**
 *
 * @author timber
 */
public abstract class DirectionManager extends Direction{
    protected Renderable subject;
}
